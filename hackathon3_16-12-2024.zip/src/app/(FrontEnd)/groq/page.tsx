import { groq } from "./lib.js"

export default function grouq(){
    return(
        <>
        </>
    )
}