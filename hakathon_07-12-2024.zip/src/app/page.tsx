import Image from 'next/image'
import HomeProducts1 from './components/HomeProducts1'
import VMenu from './components/VMenu'
import FlashSales from './components/FlashSales'
import BestSelling from './components/BestSelling'
import ExploreProducts from './components/ExploreProducts'
import NewArrival from './components/NewArrival'
import InfoIcons from './components/InfoIcons'

export default function Home() {
  return (
    <>
      <div className="container mx-auto px-8">
          <div className="flex">
            {/* Left Menu */}
            <div className="flex-none w-1/4 bg-white-200 p-4" style={{height:"370px"}}>
              <VMenu/>
            </div>
            
            {/* Main Content */}
            <div className="flex-grow bg-white-200 p-4" style={{height:"370px"}}>
              <img src="img/voucher.png"  style={{height:"344px"}}/>
            </div>
          </div>
          <div>
            <FlashSales/>
          </div>
          <div>
            <BestSelling />
          </div>

          <div className='mb-10'>
            <img src="img/banner2.png"  style={{height:"500px"}}/>
          </div>
          
          <div>
            <ExploreProducts />
          </div>

          <div>
            <NewArrival/>
          </div>
          
          <div>
            <InfoIcons/>
          </div>
      </div>
    
    </>
  )
}
