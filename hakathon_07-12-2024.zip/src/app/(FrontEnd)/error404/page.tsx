export default function Error404() {
  return (
    <>
      <p>Error404</p>
    </>
  )
}
