
export default function Account() {
  return (
    <>
      <div className="container mx-auto px-8">
        <div className="mt-10 font-[sans-serif] bg-white">
        <div className="flex max-sm:flex-col gap-12 max-lg:gap-2">
          
        <div className=" ml-10 px-10 py-10 from-gray-800 via-gray-700 to-gray-800 sm:h-screen sm:sticky sm:top-0 lg:min-w-[470px] sm:min-w-[300px]">
            <div className="relative ">
              <div>
                <h3>Manage My Account</h3>
                <ul className="ml-8 text-gray-400 text-sm">
                  <li style={{ color:"red" }}>My Profile</li>  
                  <li>Address Book</li>  
                  <li>My Payment Options</li>  
                </ul>  
              </div>
              <div className="mt-4">
                <h3>My Orders</h3>
                <ul className="ml-8 text-gray-400 text-sm">
                  <li>My Return</li>  
                  <li>My Cancellation</li>  
                </ul>  
              </div>
              <div className="mt-4">
                <h3>Wishlist</h3>
              </div>
              

            </div>
          </div>

          <div className="max-w-xl w-full h-max rounded-md px-3 py-8 sticky top-0">
            <h2 className="text-2xl font-bold text-gray-800 text-red-400" >Edit Your Profile</h2>
            <form className="mt-8">
              <div>
               
                <div className="grid md:grid-cols-1 gap-4">
                <div>
                    <label className="text-gray-500">First Name</label>
                    <input type="text"
                      className="px-3 py-2 bg-gray-100 focus:bg-transparent text-gray-800 w-full text-sm rounded-md focus:outline-blue-600" />
                  </div>

                  <div>
                  <label className="text-gray-500">Company Name</label>
                    <input type="text" 
                      className="px-3 py-2 bg-gray-100 focus:bg-transparent text-gray-800 w-full text-sm rounded-md focus:outline-blue-600" />
                  </div>

                  <div>
                  <label className="text-gray-500">Street Address</label>
                    <input type="email" 
                      className="px-3 py-2 bg-gray-100 focus:bg-transparent text-gray-800 w-full text-sm rounded-md focus:outline-blue-600" />
                  </div>

                  <div>
                  <label className="text-gray-500">Apartment,floor,etc. (optional)</label>
                    <input type="number" placeholder="Phone No."
                      className="px-3 py-2 bg-gray-100 focus:bg-transparent text-gray-800 w-full text-sm rounded-md focus:outline-blue-600" />
                  </div>



                  <div>
                  <label className="text-gray-500">City/Town</label>
                    <input type="email" 
                      className="px-3 py-2 bg-gray-100 focus:bg-transparent text-gray-800 w-full text-sm rounded-md focus:outline-blue-600" />
                  </div>

                  <div>
                  <label className="text-gray-500">Phone Number</label>
                    <input type="email" 
                      className="px-3 py-2 bg-gray-100 focus:bg-transparent text-gray-800 w-full text-sm rounded-md focus:outline-blue-600" />
                  </div>

                  <div>
                  <label className="text-gray-500">Email Address</label>
                    <input type="email" 
                      className="px-3 py-2 bg-gray-100 focus:bg-transparent text-gray-800 w-full text-sm rounded-md focus:outline-blue-600" />
                  </div>

                  <div className="flex flex-col-reverse">
                  <span className="text-gray-500 ">Save the information for faster check-out next time.</span>
                    <input type="checkbox" 
                      className="float-start bg-gray-100 focus:bg-transparent text-gray-800 text-sm rounded-md focus:outline-blue-600" />
                       
                  </div>
                </div>
              </div>

              
            </form>
          </div>
          
          

          
        </div>
        </div>
      </div>
    </>
  )
}
