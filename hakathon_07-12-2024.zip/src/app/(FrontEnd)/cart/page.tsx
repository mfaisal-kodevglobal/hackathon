export default function Cart() {
  return (
    <>
      <div className="container mx-auto px-8">
        <div className="font-sans bg-white max-w-6xl mx-auto p-4">
        <label  className="ml-3 block text-sm">
          Home / Cart
        </label>
        <div className="overflow-x-auto">
          <table className="mt-12 w-full border-collapse divide-y">

            <thead className="whitespace-nowrap text-left">
              <tr>
                <th className="text-base text-gray-500 font-medium p-2">Product</th>
                <th className="text-base text-gray-500 font-medium p-2">Price</th>
              
                <th className="text-base text-gray-500 font-medium p-2">Quantity</th>
                <th className="text-base text-gray-500 font-medium p-2">Subtotal</th>
                

              </tr>
            </thead>

            <tbody className="whitespace-nowrap divide-y">
              <tr>
                <td className="px-2 py-4">
                  <div className="flex items-center gap-4 w-max">
                    <div className=" shrink-0">
                      <img src='img/products/fs3.png' className="w-9 h-full object-contain " />
                    </div>

                    <div>
                      <p className="text-base font-bold text-gray-800">Black T-Shirt</p>
                    </div>
                  </div>
                </td>
                <td className="px-2 py-4">
                  <h4 className="text-base font-bold text-gray-800">$18.5</h4>
                </td>
                <td className="px-2 py-4">
                  <div className="flex overflow-hidden border w-max rounded-lg">
                      <form className="max-w-sm mx-auto">
                          <input type="number" id="number-input" aria-describedby="helper-text-explanation" className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-sm focus:border-gray-300 block w-14 p-1.5 dark:border-gray-300 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:border-gray-300 dark:focus:border-gray-300" placeholder="90210" required />
                      </form>
                  </div>
                </td>
                <td className="px-2 py-4">
                <h4 className="text-base font-bold text-gray-800">$18.5</h4>
                </td>
              </tr>
              <tr>
                <td className="px-2 py-4">
                  <div className="flex items-center gap-4 w-max">
                    <div className=" shrink-0">
                      <img src='img/products/fs1.png' className="w-9 h-full object-contain " />
                    </div>

                    <div>
                      <p className="text-base font-bold text-gray-800">Black T-Shirt</p>
                    </div>
                  </div>
                </td>
                <td className="px-2 py-4">
                  <h4 className="text-base font-bold text-gray-800">$18.5</h4>
                </td>
                <td className="px-2 py-4">
                  <div className="flex overflow-hidden border w-max rounded-lg">
                      <form className="max-w-sm mx-auto">
                          <input type="number" id="number-input" aria-describedby="helper-text-explanation" className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-sm focus:border-gray-300 block w-14 p-1.5 dark:border-gray-300 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:border-gray-300 dark:focus:border-gray-300" placeholder="90210" required />
                      </form>
                  </div>
                </td>
                <td className="px-2 py-4">
                <h4 className="text-base font-bold text-gray-800">$18.5</h4>
                </td>
              </tr>

            </tbody>
          </table>
        </div>
        <div className="flex-col-reverse">
        <button className="bg-white px-5 py-1 float-end border-2 rounded text-500">Update Cart </button>
        <button className="bg-white px-5 py-1 float-start border-2 rounded text-md">Return To Shop </button>
      </div>
      <br/><br/><br/>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-30" >
        <div className="max-w-md p-3 flex flex-wrap" >
         
                  <div className="flex overflow-hidden w-max rounded-lg">
                      <form className="max-w-sm mx-auto">
                          <input type="text" id="number-input" aria-describedby="helper-text-explanation" className="border-2 mr-5 bg-gray-50 border-gray-300 text-gray-900 text-sm rounded-sm focus:border-gray-300 block w-full p-1.5 dark:border-gray-300 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:border-gray-300 dark:focus:border-gray-300" placeholder="Coupon Code" required />
                      </form>
                  </div>

                  <div className="float-start ml-16">
                    <button className="bg-[#DB4444] px-5 py-1 float-start border-2 rounded text-md">Apply Coupon </button>
                  </div>
        </div>
        
        <div className="max-w-xl p-3" style={{ border:"1px solid black",height:'324px' }}>
          <label className="p-3"><b>Cart Total</b></label>
          <ul className="text-gray-800 divide-y">
            <li className="flex flex-wrap gap-3 text-base py-3">Subtotal <span className="ml-auto font-bold">$37.00</span></li>
            <li className="flex flex-wrap gap-3 text-base py-3">Shipping <span className="ml-auto font-bold">$4.00</span></li>
            <li className="flex flex-wrap gap-3 text-base py-3 font-bold">Total <span className="ml-auto">$45.00</span></li>
          </ul>
          <button type="button" className="text-deco mt-6 text-base tracking-wide px-3 py-1.5 w-60 bg-[#DB4444] text-white rounded-sm">Process to Checkout</button>
        </div>
        </div>
        </div>
      </div>
    </>
  )
}
