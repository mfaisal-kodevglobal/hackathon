export default function Checkout() {
  return (
    <>
     <div className="container mx-auto px-8">
        <div className="mt-10 font-[sans-serif] bg-white">
        <div className="flex max-sm:flex-col gap-12 max-lg:gap-4">
          
          <div className="max-w-xl w-full h-max rounded-md px-3 py-8 sticky top-0">
            <h2 className="text-2xl font-bold text-gray-800">Billing Details</h2>
            <form className="mt-8">
              <div>
               
                <div className="grid md:grid-cols-1 gap-4">
                <div>
                    <label className="text-gray-500">First Name</label>
                    <input type="text"
                      className="px-3 py-2 bg-gray-100 focus:bg-transparent text-gray-800 w-full text-sm rounded-md focus:outline-blue-600" />
                  </div>

                  <div>
                  <label className="text-gray-500">Company Name</label>
                    <input type="text" 
                      className="px-3 py-2 bg-gray-100 focus:bg-transparent text-gray-800 w-full text-sm rounded-md focus:outline-blue-600" />
                  </div>

                  <div>
                  <label className="text-gray-500">Street Address</label>
                    <input type="email" 
                      className="px-3 py-2 bg-gray-100 focus:bg-transparent text-gray-800 w-full text-sm rounded-md focus:outline-blue-600" />
                  </div>

                  <div>
                  <label className="text-gray-500">Apartment,floor,etc. (optional)</label>
                    <input type="number" placeholder="Phone No."
                      className="px-3 py-2 bg-gray-100 focus:bg-transparent text-gray-800 w-full text-sm rounded-md focus:outline-blue-600" />
                  </div>



                  <div>
                  <label className="text-gray-500">City/Town</label>
                    <input type="email" 
                      className="px-3 py-2 bg-gray-100 focus:bg-transparent text-gray-800 w-full text-sm rounded-md focus:outline-blue-600" />
                  </div>

                  <div>
                  <label className="text-gray-500">Phone Number</label>
                    <input type="email" 
                      className="px-3 py-2 bg-gray-100 focus:bg-transparent text-gray-800 w-full text-sm rounded-md focus:outline-blue-600" />
                  </div>

                  <div>
                  <label className="text-gray-500">Email Address</label>
                    <input type="email" 
                      className="px-3 py-2 bg-gray-100 focus:bg-transparent text-gray-800 w-full text-sm rounded-md focus:outline-blue-600" />
                  </div>

                  <div className="flex flex-col-reverse">
                  <span className="text-gray-500 ">Save the information for faster check-out next time.</span>
                    <input type="checkbox" 
                      className="float-start bg-gray-100 focus:bg-transparent text-gray-800 text-sm rounded-md focus:outline-blue-600" />
                       
                  </div>
                </div>
              </div>

              
            </form>
          </div>
          
          <div className="py-16 from-gray-800 via-gray-700 to-gray-800 sm:h-screen sm:sticky sm:top-0 lg:min-w-[470px] sm:min-w-[300px]">
            <div className="relative ">
              <div className="px-3 py-8 sm:overflow-auto sm:h-[calc(100vh-60px)]">
                <div className="space-y-4">

                  <div className="flex items-start gap-4">
                    <div className="w-22  max-lg:w-24 max-lg:h-24 flex p-3 shrink-0">
                      <img src='img/products/fs3.png' className="w-9 h-full object-contain " />
                    </div>
                    <div className="w-full">
                      <h3 className="text-base text-white"></h3>
                      <ul className="mt-5 text-xs text-gray-500">
                        <li className="flex flex-wrap gap-4">Split Sneakers<span className="ml-auto">$650</span></li>
                      </ul>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="w-22  max-lg:w-24 max-lg:h-24 flex p-3 shrink-0">
                    <img src='img/products/fs1.png' className="w-9 h-full object-contain " />
                    </div>
                    <div className="w-full">
                      <h3 className="text-base text-white"></h3>
                      <ul className="mt-5 text-xs text-gray-500 ">
                        <li>Velvet Boots<span className="float-right">$1100</span></li>
                      </ul>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="w-full">
                      <h3 className="text-base text-white"></h3>
                      <ul className="ml-5 text-xs text-gray-500 ">
                        <li  style={{ borderBottom:"1px solid gray" }}>Subtotal<span className="float-right">$1750</span></li>
                        <li className="py-2" style={{ borderBottom:"1px solid gray" }}>Shipping<span className="float-right">Free</span></li>
                        <li className="py-2">Total<span className="float-right">$1750</span></li>
                      </ul>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="w-full">
                      <h3 className="text-base text-white"></h3>
                      <ul className="ml-5 text-xs text-gray-500 ">
                        <li><span className="float-left mr-3"><input type="radio" /></span> Bank </li><br/>
                        <li><span className="float-left mr-3"><input type="radio" /></span> Cash on delivery </li>
                      </ul>
                    </div>
                  </div>

                  <div className="max-w-md p-3 flex flex-wrap" >
         
                          <div className="flex overflow-hidden w-max rounded-lg">
                              <form className="max-w-sm mx-auto">
                                  <input type="text" id="number-input" aria-describedby="helper-text-explanation" className="border-2 mr-5 bg-gray-50 border-gray-300 text-gray-900 text-sm rounded-sm focus:border-gray-300 block w-full p-1.5 dark:border-gray-300 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:border-gray-300 dark:focus:border-gray-300" placeholder="Coupon Code" required />
                              </form>
                          </div>

                          <div className="float-start ml-16">
                            <button className="bg-[#DB4444] px-5 py-1 float-start border-2 rounded text-md">Apply Coupon </button>
                          </div>
                  </div>

                  <div className="max-w-md p-3 flex flex-wrap" >
         
                          <div className="float-start">
                            <button className="bg-[#DB4444] px-5 py-1 float-start border-2 rounded text-md">Place Order</button>
                          </div>
                  </div>

                </div>
              </div>

            </div>
          </div>

          
        </div>
        </div>
      </div>
    </>
  )
}
