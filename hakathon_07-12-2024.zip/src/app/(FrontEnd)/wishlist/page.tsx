import JustForYou from "@/app/components/JustForYou";
import WishlistProducts from "@/app/components/WishListProducts";

export default function Wishlist() {
  return (
    <>
    <div className="container mx-auto px-8">
        <div>
          <WishlistProducts/>
        </div>

        <div>
          <JustForYou/>
        </div>
      </div>
    </>
  )
}
