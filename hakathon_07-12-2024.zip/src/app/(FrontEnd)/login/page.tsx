export default function Login() {
  return (
    <>
       <div className="container mx-auto px-8">
       <div className="font-[sans-serif]">
          <div className="grid lg:grid-cols-3 md:grid-cols-2 items-center gap-4 h-full">
            <div className="max-md:order-1 lg:col-span-2 md:h-screen w-full md:rounded-tr-xl md:rounded-br-xl lg:p-12 p-8">
              <img src="img/login.png" className="w-full h-full  block mx-auto" alt="login-image" />
            </div>

            <div className="w-full p-6">
              <form>
                <div className="mb-8">
                  <h3 className="text-gray-800 text-3xl font-extrabold">Log in to Exclusive</h3>
                  <p className="text-sm mt-4 text-gray-800">Enter you details below</p>
                </div>
                <div>
                  <div className="relative flex items-center mb-3 border-b-2">
                    <input name="email" type="text" required className="w-full text-sm text-gray-800  focus:bg-transparent px-4 py-3.5 rounded-md outline-blue-600" placeholder="Email or Phone Number" />
                    
                  </div>
                </div>

                <div className="mt-4">
                  <div className="relative flex items-center mb-3 border-b-2">
                    <input name="password" type="password" required className="w-full text-sm text-gray-800  focus:bg-transparent px-4 py-3.5 rounded-md outline-blue-600" placeholder="Enter password" />
                   
                  </div>
                </div>

                

                

                

               

                <div className="flex">
                  <div className="mt-5 mb-3 float-start">
                    <button type="button" className="py-3 px-6 text-sm tracking-wide rounded-sm text-white bg-[#DB4444]  focus:outline-none">
                      Log In
                    </button>
                  </div>

                  <div className="float-end ml-18">
                    <label  className="mt-10 ml-20 block text-sm" style={{ color:"#DB4444" }}>Forgot Password?</label>
                  </div>
                  
                </div>
              </form>
            </div>
          </div>
       </div>
     </div>
    </>
  )
}
