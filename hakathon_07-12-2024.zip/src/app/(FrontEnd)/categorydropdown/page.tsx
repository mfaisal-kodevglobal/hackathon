import BestSelling from "@/app/components/BestSelling";
import ExploreProducts from "@/app/components/ExploreProducts";
import FlashSales from "@/app/components/FlashSales";
import InfoIcons from "@/app/components/InfoIcons";
import NewArrival from "@/app/components/NewArrival";
import VMenu from "@/app/components/VMenu";

export default function CategoryDropdown() {
  return (
    <>
            <div className="container mx-auto px-8">
          <div className="flex">
            {/* Left Menu */}
            <div className="flex-none w-1/4 bg-white-200 p-4" style={{height:"370px"}}>
              <VMenu/>
            </div>
            
            {/* Main Content */}
            <div className="flex-grow bg-white-200 p-4" style={{height:"370px"}}>
              <img src="img/voucher.png"  style={{height:"344px"}}/>
            </div>
          </div>
          <div>
            <FlashSales/>
          </div>
          <div>
            <BestSelling />
          </div>

          <div className='mb-10'>
            <img src="img/banner2.png"  style={{height:"500px"}}/>
          </div>
          
          <div>
            <ExploreProducts />
          </div>

          <div>
            <NewArrival/>
          </div>
          
          <div>
            <InfoIcons/>
          </div>
      </div>
    </>
  )
}
