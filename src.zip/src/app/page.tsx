import Image from 'next/image'
import HomeProducts1 from './components/HomeProducts1'
import VMenu from './components/VMenu'
import FlashSales from './components/FlashSales'

export default function Home() {
  return (
    <>
        <div className="flex gap-4 h-screen">
      {/* Left Menu */}
      <div className="flex-none w-1/4 bg-gray-200 p-4">
        <VMenu/>
      </div>
      
      {/* Main Content */}
      <div className="flex-grow bg-gray-100 p-4">
        <h1 className="text-xl font-bold">Welcome to the Product Page</h1>
        <p>Select a product from the menu to get started.</p>
      </div>
    </div>
    <div>
      <FlashSales/>
    </div>
    </>
  )
}
