import HomeProducts1 from "@/app/components/HomeProducts1";

export default function Wishlist() {
  return (
    <>
      <HomeProducts1/>
    </>
  )
}
