
export default function Account() {
  return (
    <>
      <p>Account</p>
    </>
  )
}
